`timescale 1ns / 1ps
// =====================================================================
// FILE: tb_alu.v (CUSTOMIZED VERSION)
// Upgrades: 
// - Checks for Negative (N) and Overflow (V) flags
// - Tests new SHL (Shift Left) instruction
// - Advanced 2's complement arithmetic edge cases
// =====================================================================
module tb_alu;

    reg  [3:0] a, b;
    reg  [2:0] alu_ctrl;
    wire [3:0] result;
    wire       carry, zero, negative, overflow; // Cập nhật thêm N và V

    integer errors = 0;
    integer tests  = 0;

    // KẾT NỐI VỚI ALU NÂNG CẤP
    alu DUT (
        .a(a), .b(b), .alu_ctrl(alu_ctrl),
        .result(result), .carry(carry), .zero(zero),
        .negative(negative), .overflow(overflow) // Cổng mới
    );

    // TASK KIỂM TRA ĐƯỢC NÂNG CẤP
    task test;
        input [8*15:1] name;
        input [3:0]    in_a, in_b;
        input [2:0]    op;
        input [3:0]    exp_result;
        input          exp_carry;
        input          exp_zero;
        input          exp_neg;  // Kỳ vọng cờ Âm
        input          exp_ovf;  // Kỳ vọng cờ Tràn số
        begin
            a = in_a;  b = in_b;  alu_ctrl = op;
            #10;
            tests = tests + 1;
            if (result == exp_result && carry == exp_carry && zero == exp_zero && negative == exp_neg && overflow == exp_ovf)
                $display("PASS  %0s a=%b b=%b -> res=%b C=%b Z=%b N=%b V=%b",
                         name, a, b, result, carry, zero, negative, overflow);
            else begin
                $display("FAIL  %0s a=%b b=%b -> res=%b C=%b Z=%b N=%b V=%b",
                         name, a, b, result, carry, zero, negative, overflow);
                $display("      expected res=%b C=%b Z=%b N=%b V=%b",
                         exp_result, exp_carry, exp_zero, exp_neg, exp_ovf);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        $display("\n===== tb_alu: CUSTOM ALU MODULE TEST =====");
        //      name               a        b        ctrl  result   C  Z  N  V
        // TÍNH TOÁN BÌNH THƯỜNG
        test("ADD 2+3        ", 4'b0010, 4'b0011, 3'd0, 4'b0101, 0, 0, 0, 0);
        test("SUB 5-3        ", 4'b0101, 4'b0011, 3'd1, 4'b0010, 1, 0, 0, 0);
        
        // TEST KIẾN THỨC SÂU VỀ SỐ CÓ DẤU (SIGNED NUMBER)
        // 5 + 3 = 8. Nhưng trong 4-bit signed, max là 7. Kết quả 1000 là -8 -> Tràn số (V=1), Âm (N=1)
        test("ADD 5+3 (Ovf)  ", 4'b0101, 4'b0011, 3'd0, 4'b1000, 0, 0, 1, 1);
        
        // -8 - 1 = -9. Tràn đáy (Underflow). Kết quả 0111 là 7 -> Tràn số (V=1), Dương (N=0)
        test("SUB -8-1 (Ovf) ", 4'b1000, 4'b0001, 3'd1, 4'b0111, 1, 0, 0, 1);
        
        // 3 - 5 = -2. Không tràn số (V=0), Kết quả 1110 là -2 -> Âm (N=1). C=0 (mượn)
        test("SUB 3-5 (Neg)  ", 4'b0011, 4'b0101, 3'd1, 4'b1110, 0, 0, 1, 0);

        // TEST CÁC LỆNH LOGIC & LỆNH MỚI SHL
        test("AND            ", 4'b1100, 4'b1010, 3'd2, 4'b1000, 0, 0, 1, 0);
        test("XOR to zero    ", 4'b0110, 4'b0110, 3'd4, 4'b0000, 0, 1, 0, 0);
        
        // LỆNH MỚI THÊM VÀO: Dịch trái 0101 (5) thành 1010 (10)
        test("SHL 0101 ->1010", 4'b0101, 4'b0000, 3'd7, 4'b1010, 0, 0, 1, 0);

        if (errors == 0)
            $display("tb_alu PASSED: %0d of %0d tests OK\n", tests, tests);
        else
            $display("tb_alu FAILED: %0d of %0d tests failed\n", errors, tests);
        $finish;
    end
endmodule