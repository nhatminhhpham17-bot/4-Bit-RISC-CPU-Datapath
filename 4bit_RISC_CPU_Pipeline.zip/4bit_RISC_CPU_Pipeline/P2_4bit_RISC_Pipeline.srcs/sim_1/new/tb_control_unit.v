`timescale 1ns / 1ps
// =====================================================================
// FILE: tb_control_unit.v (CUSTOMIZED VERSION)
// Upgrades: Checks N and V enables, SHL opcode, and Early JMP
// =====================================================================
module tb_control_unit;

    reg  [3:0] opcode    = 4'b0000;
    reg        ex_is_jz  = 0;
    reg        zero_flag = 0;

    wire [2:0] alu_ctrl;
    wire       alu_src_sel, wb_sel, reg_we, mem_we;
    wire       zero_we, carry_we, neg_we, ovf_we;
    wire       id_pc_sel, id_flush;
    wire       ex_pc_sel, ex_flush;

    integer errors = 0;
    integer tests  = 0;

    control_unit DUT (
        .opcode(opcode), .alu_ctrl(alu_ctrl), .alu_src_sel(alu_src_sel),
        .wb_sel(wb_sel), .reg_we(reg_we), .mem_we(mem_we),
        .zero_we(zero_we), .carry_we(carry_we), .neg_we(neg_we), .ovf_we(ovf_we),
        .id_pc_sel(id_pc_sel), .id_flush(id_flush),
        .ex_is_jz(ex_is_jz), .zero_flag(zero_flag),
        .ex_pc_sel(ex_pc_sel), .ex_flush(ex_flush)
    );

    // Pack: alu_ctrl[2:0], src, wb, rwe, mwe, zwe, cwe, nwe, vwe
    wire [11:0] signals = {alu_ctrl, alu_src_sel, wb_sel, reg_we, mem_we,
                           zero_we, carry_we, neg_we, ovf_we};

    task check_op;
        input [8*6:1] name;
        input [3:0]   op;
        input [11:0]  expected;
        begin
            opcode = op;  #1;
            tests = tests + 1;
            if (signals == expected)
                $display("PASS  %0s alu=%0d src=%b wb=%b rwe=%b mwe=%b zwe=%b cwe=%b nwe=%b vwe=%b",
                         name, alu_ctrl, alu_src_sel, wb_sel, reg_we, mem_we,
                         zero_we, carry_we, neg_we, ovf_we);
            else begin
                $display("FAIL  %0s got %b, expected %b", name, signals, expected);
                errors = errors + 1;
            end
        end
    endtask

    task check_id_jump;
        input [8*24:1] name;
        input [3:0]    op;
        input          exp_pc_sel;
        begin
            opcode = op; #1;
            tests = tests + 1;
            if (id_pc_sel == exp_pc_sel && id_flush == exp_pc_sel)
                $display("PASS  %0s id_pc_sel=%b id_flush=%b", name, id_pc_sel, id_flush);
            else begin
                $display("FAIL  %0s id_pc_sel=%b id_flush=%b (expected %b)",
                         name, id_pc_sel, id_flush, exp_pc_sel);
                errors = errors + 1;
            end
        end
    endtask

    task check_ex_branch;
        input [8*24:1] name;
        input          jz, z;
        input          exp_pc_sel;
        begin
            ex_is_jz = jz;  zero_flag = z;  #1;
            tests = tests + 1;
            if (ex_pc_sel == exp_pc_sel && ex_flush == exp_pc_sel)
                $display("PASS  %0s ex_pc_sel=%b ex_flush=%b", name, ex_pc_sel, ex_flush);
            else begin
                $display("FAIL  %0s ex_pc_sel=%b ex_flush=%b (expected %b)",
                         name, ex_pc_sel, ex_flush, exp_pc_sel);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        $display("\n===== tb_control_unit: CUSTOMIZED =====");
        $display("--- Part A: Decoder ---");
        //          name     opcode    alu   src   wb   rwe  mwe  zwe  cwe  nwe  vwe
        check_op("ADD   ", 4'b0000, {3'd0, 1'b0, 1'b0, 1'b1, 1'b0, 1'b1, 1'b1, 1'b1, 1'b1});
        check_op("SUB   ", 4'b0001, {3'd1, 1'b0, 1'b0, 1'b1, 1'b0, 1'b1, 1'b1, 1'b1, 1'b1});
        check_op("AND   ", 4'b0010, {3'd2, 1'b0, 1'b0, 1'b1, 1'b0, 1'b1, 1'b0, 1'b1, 1'b0});
        check_op("SHL   ", 4'b1100, {3'd7, 1'b0, 1'b0, 1'b1, 1'b0, 1'b1, 1'b0, 1'b1, 1'b0});
        
        $display("--- Part B: ID Stage JMP Optimization ---");
        check_id_jump("Normal instruction      ", 4'b0000, 0);
        check_id_jump("JMP (Early Resolution)  ", 4'b1010, 1);

        $display("--- Part C: EX Stage JZ ---");
        check_ex_branch("JZ with Zero = 0        ", 1, 0, 0);
        check_ex_branch("JZ with Zero = 1        ", 1, 1, 1);

        if (errors == 0)
            $display("tb_control_unit PASSED: %0d of %0d checks OK\n", tests, tests);
        else
            $display("tb_control_unit FAILED: %0d of %0d checks failed\n", errors, tests);
        $finish;
    end
endmodule