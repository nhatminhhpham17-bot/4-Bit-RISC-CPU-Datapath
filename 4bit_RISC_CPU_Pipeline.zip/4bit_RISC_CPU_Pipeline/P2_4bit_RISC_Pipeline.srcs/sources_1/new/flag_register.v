module flag_register (
    input      clk,
    input      rst,
    input      zero_we,     
    input      carry_we, 
    input      neg_we,
    input      ovf_we,
    input      zero_in,     
    input      carry_in,    
    input      neg_in,      
    input      ovf_in,      
    output reg zero_flag,   
    output reg carry_flag,  
    output reg neg_flag,    
    output reg ovf_flag     
);
    always @(posedge clk) begin
        if (rst) begin
            zero_flag  <= 1'b0; carry_flag <= 1'b0; neg_flag <= 1'b0; ovf_flag <= 1'b0;
        end
        else begin
            if (zero_we)  zero_flag  <= zero_in;
            if (carry_we) carry_flag <= carry_in;
            if (neg_we)   neg_flag   <= neg_in;
            if (ovf_we)   ovf_flag   <= ovf_in;
        end
    end
endmodule