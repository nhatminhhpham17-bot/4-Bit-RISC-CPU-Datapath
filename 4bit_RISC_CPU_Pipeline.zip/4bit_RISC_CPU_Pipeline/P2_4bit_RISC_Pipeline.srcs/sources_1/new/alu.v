module adder_subtractor (
    input      [3:0] a,
    input      [3:0] b,
    input            do_sub,     
    output reg [3:0] result,
    output reg       carry,
    output reg       overflow
);
    reg [4:0] full_sum;          
    wire [3:0] bx = do_sub ? ~b : b;

    always @(*) begin
        full_sum = a + bx + do_sub;  
        result   = full_sum[3:0];    
        if (do_sub == 1'b0) carry = full_sum[4];
        else carry = (a >= b) ? 1'b1 : 1'b0;
        overflow = (~a[3] & ~bx[3] & result[3]) | (a[3] & bx[3] & ~result[3]);
    end
endmodule

module logic_unit (
    input      [3:0] a,
    input      [3:0] b,
    input      [2:0] alu_ctrl,
    output reg [3:0] result
);
    always @(*) begin
        case (alu_ctrl)
            3'd2:    result = a & b;     
            3'd3:    result = a | b;     
            3'd4:    result = a ^ b;     
            3'd5:    result = ~a;        
            3'd6:    result = b;         
            3'd7:    result = a << 1;    // SHL
            default: result = 4'b0000;
        endcase
    end
endmodule

module zero_detector (
    input  [3:0] value,
    output       zero
);
    assign zero = (value == 4'b0000) ? 1'b1 : 1'b0;
endmodule

module alu (
    input      [3:0] a,          
    input      [3:0] b,          
    input      [2:0] alu_ctrl,   
    output reg [3:0] result,     
    output reg       carry,      
    output           zero,       
    output           negative,   
    output reg       overflow    
);
    wire [3:0] arith_result;     
    wire       arith_carry;      
    wire       arith_overflow;
    wire [3:0] logic_result;     
    wire do_sub = (alu_ctrl == 3'd1);    

    adder_subtractor ADDSUB (.a(a), .b(b), .do_sub(do_sub), .result(arith_result), .carry(arith_carry), .overflow(arith_overflow));
    logic_unit LOGIC (.a(a), .b(b), .alu_ctrl(alu_ctrl), .result(logic_result));

    always @(*) begin
        if (alu_ctrl == 3'd0 || alu_ctrl == 3'd1) begin
            result   = arith_result;       
            carry    = arith_carry;
            overflow = arith_overflow;
        end
        else begin
            result   = logic_result;       
            carry    = 1'b0;               
            overflow = 1'b0; 
        end
    end
    zero_detector ZERO (.value(result), .zero(zero));
    assign negative = result[3];
endmodule