module pipeline_register (
    input             clk, rst, flush,
    input      [2:0]  alu_ctrl_in,
    input             alu_src_sel_in, wb_sel_in, reg_we_in, mem_we_in,
    input             zero_we_in, carry_we_in, neg_we_in, ovf_we_in, is_jz_in,
    input      [1:0]  rd_in, rs_in,
    input      [3:0]  imm_in, pc_in,
    input             valid_in,
    input      [11:0] instr_in,
    output reg [2:0]  alu_ctrl,
    output reg        alu_src_sel, wb_sel, reg_we, mem_we,
    output reg        zero_we, carry_we, neg_we, ovf_we, is_jz,
    output reg [1:0]  rd, rs,
    output reg [3:0]  imm, pc,
    output reg        valid,
    output reg [11:0] instr
);
    always @(posedge clk) begin
        if (rst || flush) begin
            alu_ctrl<=0; alu_src_sel<=0; wb_sel<=0; reg_we<=0; mem_we<=0; zero_we<=0; carry_we<=0; neg_we<=0; ovf_we<=0; is_jz<=0;
            rd<=0; rs<=0; imm<=0; pc<=0; valid<=0; instr<=12'hC00;
        end else begin
            alu_ctrl<=alu_ctrl_in; alu_src_sel<=alu_src_sel_in; wb_sel<=wb_sel_in; reg_we<=reg_we_in; mem_we<=mem_we_in;
            zero_we<=zero_we_in; carry_we<=carry_we_in; neg_we<=neg_we_in; ovf_we<=ovf_we_in; is_jz<=is_jz_in;
            rd<=rd_in; rs<=rs_in; imm<=imm_in; pc<=pc_in; valid<=valid_in; instr<=instr_in;
        end
    end
endmodule