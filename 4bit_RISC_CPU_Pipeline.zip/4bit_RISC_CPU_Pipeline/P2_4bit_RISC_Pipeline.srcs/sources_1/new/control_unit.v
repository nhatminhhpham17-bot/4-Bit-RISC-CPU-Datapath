module instruction_decoder (
    input      [3:0] opcode,      
    output reg [2:0] alu_ctrl,    
    output reg       alu_src_sel, 
    output reg       wb_sel,      
    output reg       reg_we,      
    output reg       mem_we,      
    output reg       zero_we,     
    output reg       carry_we,    
    output reg       neg_we,      
    output reg       ovf_we,      
    output reg       is_jmp,      
    output reg       is_jz        
);
    always @(*) begin
        alu_ctrl=3'd0; alu_src_sel=0; wb_sel=0; reg_we=0; mem_we=0; zero_we=0; carry_we=0; neg_we=0; ovf_we=0; is_jmp=0; is_jz=0;
        case (opcode)
            4'b0000: begin alu_ctrl=3'd0; reg_we=1; zero_we=1; carry_we=1; neg_we=1; ovf_we=1; end
            4'b0001: begin alu_ctrl=3'd1; reg_we=1; zero_we=1; carry_we=1; neg_we=1; ovf_we=1; end
            4'b0010: begin alu_ctrl=3'd2; reg_we=1; zero_we=1; neg_we=1; end
            4'b0011: begin alu_ctrl=3'd3; reg_we=1; zero_we=1; neg_we=1; end
            4'b0100: begin alu_ctrl=3'd4; reg_we=1; zero_we=1; neg_we=1; end
            4'b0101: begin alu_ctrl=3'd5; reg_we=1; zero_we=1; neg_we=1; end
            4'b0110: begin alu_ctrl=3'd6; alu_src_sel=1; reg_we=1; end
            4'b0111: begin alu_ctrl=3'd6; reg_we=1; end
            4'b1000: begin alu_ctrl=3'd6; alu_src_sel=1; wb_sel=1; reg_we=1; end
            4'b1001: begin alu_ctrl=3'd6; alu_src_sel=1; mem_we=1; end
            4'b1010: begin is_jmp=1; end
            4'b1011: begin is_jz=1; end
            4'b1100: begin alu_ctrl=3'd7; reg_we=1; zero_we=1; neg_we=1; end // SHL
            default: ;
        endcase
    end
endmodule

module branch_unit (
    input      is_jz,         
    input      zero_flag,     
    output reg ex_pc_sel,     
    output     ex_flush       
);
    always @(*) begin
        if (is_jz && zero_flag) ex_pc_sel = 1'b1;                 
        else ex_pc_sel = 1'b0;                 
    end
    assign ex_flush = ex_pc_sel;                 
endmodule

module control_unit (
    input      [3:0] opcode,
    output     [2:0] alu_ctrl,
    output           alu_src_sel,
    output           wb_sel,
    output           reg_we,
    output           mem_we,
    output           zero_we,
    output           carry_we,
    output           neg_we,   
    output           ovf_we,   
    output           is_jz,
    output           id_pc_sel, 
    output           id_flush,  
    input            ex_is_jz,
    input            zero_flag,
    output           ex_pc_sel,
    output           ex_flush
);
    wire is_jmp;
    instruction_decoder DECODER (.opcode(opcode), .alu_ctrl(alu_ctrl), .alu_src_sel(alu_src_sel), .wb_sel(wb_sel), .reg_we(reg_we), .mem_we(mem_we), .zero_we(zero_we), .carry_we(carry_we), .neg_we(neg_we), .ovf_we(ovf_we), .is_jmp(is_jmp), .is_jz(is_jz));
    assign id_pc_sel = is_jmp;
    assign id_flush  = is_jmp; 
    branch_unit BRANCH (.is_jz(ex_is_jz), .zero_flag(zero_flag), .ex_pc_sel(ex_pc_sel), .ex_flush(ex_flush));
endmodule