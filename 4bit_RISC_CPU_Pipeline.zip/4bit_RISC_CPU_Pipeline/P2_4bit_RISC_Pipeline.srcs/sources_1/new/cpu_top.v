(* KEEP_HIERARCHY = "TRUE" *)
module cpu_top #(parameter PROGRAM_FILE = "program.mem")(
    input clk, rst, 
    output [3:0] pc_out, alu_out, wb_data_out,
    output [11:0] instr_out, 
    output zero_out, carry_out, neg_out, ovf_out
);
    wire ex_pc_sel, id_pc_sel, ex_flush, id_flush;             
    wire [3:0] ex_imm, id_imm, pc;                
    wire [3:0] pc_next = ex_pc_sel ? ex_imm : id_pc_sel ? id_imm : pc + 4'd1;
    
    // Ép Vivado KHÔNG ĐƯỢC coi lệnh đầu vào là hằng số
    (* DONT_TOUCH = "TRUE" *) wire [11:0] fetched;
    (* DONT_TOUCH = "TRUE" *) wire [11:0] id_instr, ex_instr;           
    
    wire [3:0] id_pc, ex_pc;
    wire id_valid, ex_valid;
    
    program_counter PC (.clk(clk), .rst(rst), .pc_en(1'b1), .pc_next(pc_next), .pc_out(pc));
    instruction_memory #(.PROGRAM_FILE(PROGRAM_FILE)) IMEM (.address(pc), .instruction(fetched));
    instruction_register IR (.clk(clk), .rst(rst), .ir_load(1'b1), .flush(ex_flush | id_flush), .instruction_in(fetched), .pc_in(pc), .instruction_out(id_instr), .pc_out(id_pc), .valid_out(id_valid));

    wire [2:0] id_alu_ctrl, ex_alu_ctrl;
    wire id_alu_src_sel, id_wb_sel, id_reg_we, id_mem_we, id_zero_we, id_carry_we, id_neg_we, id_ovf_we, id_is_jz;
    wire ex_alu_src_sel, ex_wb_sel, ex_reg_we, ex_mem_we, ex_zero_we, ex_carry_we, ex_neg_we, ex_ovf_we, ex_is_jz;
    wire [1:0] ex_rd, ex_rs;
    wire zero_flag, carry_flag, neg_flag, ovf_flag; 
    assign id_imm = id_instr[3:0];

    // Bắt buộc tổng hợp Control Unit
    (* DONT_TOUCH = "TRUE" *) control_unit CU (
        .opcode(id_instr[11:8]), .alu_ctrl(id_alu_ctrl), .alu_src_sel(id_alu_src_sel), .wb_sel(id_wb_sel), .reg_we(id_reg_we), .mem_we(id_mem_we),
        .zero_we(id_zero_we), .carry_we(id_carry_we), .neg_we(id_neg_we), .ovf_we(id_ovf_we), .is_jz(id_is_jz), .id_pc_sel(id_pc_sel), .id_flush(id_flush),
        .ex_is_jz(ex_is_jz), .zero_flag(zero_flag), .ex_pc_sel(ex_pc_sel), .ex_flush(ex_flush)
    );

    pipeline_register ID_EX (
        .clk(clk), .rst(rst), .flush(ex_flush),
        .alu_ctrl_in(id_alu_ctrl), .alu_src_sel_in(id_alu_src_sel), .wb_sel_in(id_wb_sel), .reg_we_in(id_reg_we), .mem_we_in(id_mem_we),
        .zero_we_in(id_zero_we), .carry_we_in(id_carry_we), .neg_we_in(id_neg_we), .ovf_we_in(id_ovf_we), .is_jz_in(id_is_jz),
        .rd_in(id_instr[7:6]), .rs_in(id_instr[5:4]), .imm_in(id_imm), .pc_in(id_pc), .valid_in(id_valid), .instr_in(id_instr),
        .alu_ctrl(ex_alu_ctrl), .alu_src_sel(ex_alu_src_sel), .wb_sel(ex_wb_sel), .reg_we(ex_reg_we), .mem_we(ex_mem_we),
        .zero_we(ex_zero_we), .carry_we(ex_carry_we), .neg_we(ex_neg_we), .ovf_we(ex_ovf_we), .is_jz(ex_is_jz),
        .rd(ex_rd), .rs(ex_rs), .imm(ex_imm), .pc(ex_pc), .valid(ex_valid), .instr(ex_instr)
    );

    (* DONT_TOUCH = "TRUE" *) wire [3:0] rd_value, rs_value, alu_result, mem_data, wb_data;
    wire alu_zero, alu_carry, alu_neg, alu_ovf;
    
    // Bắt buộc tổng hợp Register File
    (* DONT_TOUCH = "TRUE" *) register_file RF (.clk(clk), .rst(rst), .ra(ex_rd), .rb(ex_rs), .wa(ex_rd), .wd(wb_data), .we(ex_reg_we), .qa(rd_value), .qb(rs_value));
    
    wire [3:0] wire_alu_b;
    mux2 OPERAND_MUX (.d0(rs_value), .d1(ex_imm), .sel(ex_alu_src_sel), .y(wire_alu_b));
    
    // Bắt buộc tổng hợp ALU
    (* DONT_TOUCH = "TRUE" *) alu ALU (.a(rd_value), .b(wire_alu_b), .alu_ctrl(ex_alu_ctrl), .result(alu_result), .carry(alu_carry), .zero(alu_zero), .negative(alu_neg), .overflow(alu_ovf));
    flag_register FLAGS (.clk(clk), .rst(rst), .zero_we(ex_zero_we), .carry_we(ex_carry_we), .neg_we(ex_neg_we), .ovf_we(ex_ovf_we), .zero_in(alu_zero), .carry_in(alu_carry), .neg_in(alu_neg), .ovf_in(alu_ovf), .zero_flag(zero_flag), .carry_flag(carry_flag), .neg_flag(neg_flag), .ovf_flag(ovf_flag));
    
    // Bắt buộc tổng hợp Data Memory
    (* DONT_TOUCH = "TRUE" *) data_memory DMEM (.clk(clk), .address(alu_result), .write_data(rd_value), .mem_we(ex_mem_we), .read_data(mem_data));
    mux2 WB_MUX (.d0(alu_result), .d1(mem_data), .sel(ex_wb_sel), .y(wb_data));

    assign pc_out = pc; 
    assign instr_out = ex_instr; 
    assign alu_out = alu_result; 
    assign wb_data_out = wb_data;
    assign zero_out = zero_flag; 
    assign carry_out = carry_flag; 
    assign neg_out = neg_flag; 
    assign ovf_out = ovf_flag;
endmodule